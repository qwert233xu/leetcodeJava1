package com.xu;

import com.beust.ah.A;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class App2Test {

    @Test
    public void testMaxSubArray() {
        App2 app2 = new App2();
        System.out.println(app2.MaxSubArray(new int[]{-2,1,-3,4,-1,2,1,-5,4}));
    }


    @Test
    public void testCanJump() {
        App2 app2 = new App2();
        System.out.println(app2.canJump(new int[]{2,3,1,1,4}));
        System.out.println(app2.canJump(new int[]{3,2,1,0,4}));
    }

    @Test
    public void testUniquePaths() {
        App2 app2 = new App2();
//        System.out.println(app2.uniquePaths(3, 7));
//        System.out.println(app2.uniquePaths(23, 12));
        System.out.println(app2.uniquePaths2(23, 12));
    }

    @Test
    public void testUniquePathsWithObstacles() {
        App2 app2 = new App2();
        System.out.println(app2.uniquePathsWithObstacles(new int[][]{{1, 0}}));
    }

    @Test
    public void testMinPathSum() {
        App2 app2 = new App2();
        System.out.println(app2.minPathSum(new int[][]{{1, 3, 1}, {1, 5, 1}, {4, 2, 1}}));
    }

    @Test
    public void testClimbStairs() {
        App2 app2 = new App2();
        System.out.println(app2.climbStairs(3));
    }

    @Test
    public void testGenerate() {
        App2 app2 = new App2();
        System.out.println(app2.generate(5));
    }

    @Test
    public void testPartition() {
        App2 app2 = new App2();
        System.out.println(app2.partition("aab"));
    }

    @Test
    public void testPartition_test() {
        App2 app2 = new App2();
        System.out.println(app2.partition_test("aab"));
    }

    @Test
    public void testMaxProduct() {
        App2 app2 = new App2();
//        System.out.println(app2.maxProduct(new int[]{2, 3, -2, 4}));
        System.out.println(app2.maxProduct(new int[]{-2, 0, -1}));
    }

    @Test
    public void testRob() {
        App2 app2 = new App2();
//        System.out.println(app2.rob(new int[]{2, 7, 9, 3, 1}));
//        System.out.println(app2.rob(new int[]{1,2,3,1}));
        System.out.println(app2.rob(new int[]{2,1,1,2}));
    }

    @Test
    public void testRob2() {
        App2 app2 = new App2();
        System.out.println(app2.rob2(new int[]{1, 2, 3, 1}));
    }

    @Test
    public void testNthUglyNumber() {
        App2 app2 = new App2();
        System.out.println(app2.nthUglyNumber(10));
    }

    @Test
    public void testNumSquares() {
        App2 app2 = new App2();
        System.out.println(app2.numSquares(8));
    }

    @Test
    public void testLongestPalindromeSubseq1() {
        App2 app2 = new App2();
        System.out.println(app2.longestPalindromeSubseq1("abcdaba"));
    }

    @Test
    public void testIsSubsequence() {
        App2 app2 = new App2();
        System.out.println(app2.isSubsequence("acb", "ahbgdc"));
    }

    @Test
    public void testCanPartition() {
        App2 app2 = new App2();
        System.out.println(app2.canPartition(new int[]{1, 5, 11, 5}));
    }

    @Test
    public void testCountSubstrings() {
        App2 app2 = new App2();
        System.out.println(app2.countSubstrings("abc"));
    }


}