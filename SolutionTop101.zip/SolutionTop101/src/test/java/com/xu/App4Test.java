package com.xu;

import com.xu.App4;
import junit.framework.TestCase;

public class App4Test extends TestCase {

    public void testSingleNumber() {
        App4 app4 = new App4();
        System.out.println(app4.singleNumber(new int[]{0, 1, 2, 1, 0, 1, 2, 0, 2, 99}));
    }
}