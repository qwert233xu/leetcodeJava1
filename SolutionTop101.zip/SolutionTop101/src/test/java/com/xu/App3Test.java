package com.xu;

import junit.framework.TestCase;

import java.util.Arrays;

public class App3Test extends TestCase {

    public void testRemoveKdigits() {
        App3 app3 = new App3();
//        System.out.println(app3.removeKdigits("1432219", 3));
        System.out.println(app3.removeKdigits("10001", 4));
    }

    public void testRemoveDuplicateLetters() {
        App3 app3 = new App3();
        System.out.println(app3.removeDuplicateLetters("bcabc"));
    }

    public void testMaxNumber() {
        App3 app3 = new App3();
        System.out.println(Arrays.toString(app3.maxNumber(new int[]{6,7}, new int[]{6,0,4}, 5)));
    }

    public void testPick_max() {
        App3 app3 = new App3();
        System.out.println(Arrays.toString(app3.pick_max(new int[]{9, 1, 2, 5, 8, 3}, 3)));
    }

    public void testMerge() {
        App3 app3 = new App3();
        System.out.println(Arrays.toString(app3.merge(new int[]{2,5,6,4,4,0}, new int[]{7,3,8,0,6,5,7,6,2})));
    }

    public void testReconstructQueue() {
        App3 app3 = new App3();
        System.out.println(Arrays.deepToString(app3.reconstructQueue(new int[][]{{7, 0}, {4, 4}, {7, 1}, {5, 0}, {6, 1}, {5, 2}})));
    }

    public void testDiStringMatch() {
        App3 app3 = new App3();
        System.out.println(Arrays.toString(app3.diStringMatch("IDID")));
    }

    public void testLargestPerimeter() {
        App3 app3 = new App3();
        System.out.println(app3.largestPerimeter(new int[]{2, 1, 2}));
    }

    public void testLargestSumAfterKNegations() {
        App3 app3 = new App3();
//        System.out.println(app3.largestSumAfterKNegations(new int[]{2, 3, -3, -2}, 3));
        System.out.println(app3.largestSumAfterKNegations(new int[]{2, 3, 4, 5}, 3));
    }

    public void testTestLargestSumAfterKNegations() {
        App3 app3 = new App3();
        System.out.println(app3.largestSumAfterKNegations(new int[]{8,-7,-3,-9,1,9,-6,-9,3}, 8));
    }
}