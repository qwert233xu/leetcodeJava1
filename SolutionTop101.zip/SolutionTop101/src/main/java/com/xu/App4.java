package com.xu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class App4 {

    // BitCal
    public static void main(String[] args) {

    }


    // 1、
    public int singleNumber(int[] nums) {
        int[] cnt = new int[32];
        for (int v: nums) {
            for (int i = 0; i < 32; i++) {
                if (((v>>i) & 1) == 1){
                    cnt[i]++;
                }
            }
        }

        int res = 0;

//        for (int i = 0; i < 32; i++) {
//            res += (cnt[i] % 3) * Math.pow(2, i);
//        }
        System.out.println(Arrays.toString(cnt));
        for (int i = 0; i < 32; i++) {
            if ((cnt[i] % 3 & 1) == 1){  // 只需要计算 1 就行  因为 余数 为 2
                res += (1<<i); // 考虑进位
            }
        }

        return res;
    }

    // 2、
    public List<String> findRepeatedDnaSequences(String s) {
        ArrayList<String> res = new ArrayList<>();
        HashMap<String, Integer> map = new HashMap<>();

        for (int i = 0; i + 10 <= s.length(); i++) {
            String s1 = s.substring(i, i+10);
            int count = map.getOrDefault(s1, 0);
            if (count == 1){
                res.add(s1);
            }
            map.put(s1, count+1);
        }

        return res;
    }

    // 3、
    public int reverseBits(int n) {
        int res = 0;
        for (int i = 0; i < 32; i++) {
            res<<=1;
            res += ((n>>i) & 1);
        }

        return res;
    }

    // 4、
    public int hammingWeight(int n) {
        int res = 0;
        for (int i = 0; i < 32; i++) {
            if (((n>>i) & 1) == 1){
                res++;
            }
        }

        return res;
    }

    // 5、
    public boolean isPowerOfTwo(int n) {
        return n > 0 && ((n & (n-1)) == 0);
    }

    // 6、
    public int missingNumber(int[] nums) {
        // 异或
        int ans = 0;
        for (int i = 0; i <= nums.length; i++) {
            ans ^= i;
        }

        for (int v: nums) {
            ans ^= v;
        }

        return ans;
    }

    // 7、
    public int findDuplicate(int[] nums) {
        int slow = 0;
        int fast = 0;

        slow = nums[slow];
        fast = nums[nums[fast]];

        while (slow != fast){
            slow = nums[slow];
            fast = nums[nums[fast]];
        }

        int p1 = 0;
        int p2 = slow;

        while (p1 != p2){
            p1 = nums[p1];
            p2 = nums[p2];
        }
        return p1;
    }
}
