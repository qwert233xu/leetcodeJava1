package com.xu;

import java.util.*;

// graph
public class App5 {
    public static void main(String[] args) {

    }

    // 1、
    public int[][] floodFill(int[][] image, int sr, int sc, int color) {
        int c = image[sr][sc];
        if (c != color){
            floodFill_dfs(image, sr, sc, color, c);
        }
        return image;
    }

    public void floodFill_dfs(int[][] image, int i, int j, int color, int c){
        if (i < 0 || i >= image.length || j < 0 || j >= image[0].length || image[i][j] != c){ // 相同并且相连
            return;
        }

        image[i][j] = color;

        // 上下左右
        floodFill_dfs(image, i-1, j, color, c);
        floodFill_dfs(image, i+1, j, color, c);
        floodFill_dfs(image, i, j-1, color, c);
        floodFill_dfs(image, i, j+1, color, c);
    }

    // 2、
    private int res = 0;
    public int numIslands(char[][] grid) {

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == '1'){
                    res++;
                    numIslands_dfs(grid, i, j);
                }
            }
        }
        return res;
    }

    public void numIslands_dfs(char[][] grid, int i, int j){
        if (i < 0 || i >= grid.length || j < 0 || j >= grid[0].length || grid[i][j] == '#' || grid[i][j] == '0'){
            return;
        }

        grid[i][j] = '#';


        numIslands_dfs(grid, i-1, j);
        numIslands_dfs(grid, i+1, j);
        numIslands_dfs(grid, i, j-1);
        numIslands_dfs(grid, i, j+1);

    }

    // 3、
    public int maxAreaOfIsland(int[][] grid) {
        int res = 0;

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == 1){
                    // 一个岛屿
                    res = Math.max(res, maxAreaOfIsland_dfs(grid, i, j, 0));
                }
            }
        }
        return res;
    }


    public int maxAreaOfIsland_dfs(int[][] grid, int i, int j, int count_one){
        if (i < 0 || i >= grid.length || j < 0 || j >= grid[0].length || grid[i][j] == -1 || grid[i][j] == 0){
            return 0;
        }

        grid[i][j] = -1;

        int up = maxAreaOfIsland_dfs(grid, i-1, j, count_one);
        int down = maxAreaOfIsland_dfs(grid, i+1, j, count_one);
        int left = maxAreaOfIsland_dfs(grid, i, j-1, count_one);
        int right = maxAreaOfIsland_dfs(grid, i, j+1, count_one);

        return 1 + up + down + left + right;
    }

    // 4、
    private int allDao = 0;
    private int waiDao = 0;
    public int closedIsland(int[][] grid) {
        int[][] grid2 = new int[grid.length][grid[0].length];

        for (int i = 0; i < grid.length; i++) {
            grid2[i] = Arrays.copyOf(grid[i], grid[i].length);
        }

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == 0){
                    // 一个岛屿
                    allDao++;
                    closedIsland_countOfDao(grid, i, j);
                }
            }
        }

        for (int j = 0; j < grid2[0].length; j++) {
            if (grid2[0][j] == 0){ // 上边界
                waiDao++;
                closedIsland_countOfDao(grid2, 0, j);
            }
        }

        for (int j = 0; j < grid2[0].length; j++) {
            if (grid2[grid2.length-1][j] == 0){ // 下边界
                waiDao++;
                closedIsland_countOfDao(grid2, grid2.length - 1, j);
            }
        }

        for (int i = 1; i < grid2.length - 1; i++) {
            if (grid2[i][0] == 0){ // 左边界
                waiDao++;
                closedIsland_countOfDao(grid2, i, 0);
            }
        }

        for (int i = 1; i < grid2.length - 1; i++) {
            if (grid2[i][grid2[0].length - 1] == 0){ // 右边界
                waiDao++;
                closedIsland_countOfDao(grid2, i, grid2[0].length - 1);
            }
        }

        return allDao - waiDao;
    }


    public void closedIsland_countOfDao(int[][] grid, int i, int j) {
        if (i < 0 || i >= grid.length || j < 0 || j >= grid[0].length || grid[i][j] == -1 || grid[i][j] == 1){
            return;
        }

        grid[i][j] = -1;

        closedIsland_countOfDao(grid, i-1, j);
        closedIsland_countOfDao(grid, i+1, j);
        closedIsland_countOfDao(grid, i, j-1);
        closedIsland_countOfDao(grid, i, j+1);
    }

    private HashMap<Node, Node> map = new HashMap<>();
    public Node cloneGraph(Node node) { // dfs
        if (node == null){
            return null;
        }

        if (map.containsKey(node)){
            return map.get(node);
        }

        Node newNode = new Node(node.val, new ArrayList<>());
        map.put(node, newNode);

        for (Node node1: node.neighbors) {
            newNode.neighbors.add(cloneGraph(node1)); // 处理所有的邻居
        }

        return newNode;
    }

    public Node cloneGraph2(Node node) { // bfs
        if (node == null) {
            return node;
        }

        HashMap<Node, Node> visited = new HashMap();

        // 将题目给定的节点添加到队列
        LinkedList<Node> queue = new LinkedList<Node> ();
        queue.add(node);
        // 克隆第一个节点并存储到哈希表中
        visited.put(node, new Node(node.val, new ArrayList()));

        // 广度优先搜索
        while (!queue.isEmpty()) {
            // 取出队列的头节点
            Node n = queue.remove();
            // 遍历该节点的邻居
            for (Node neighbor: n.neighbors) {
                if (!visited.containsKey(neighbor)) {
                    // 如果没有被访问过，就克隆并存储在哈希表中
                    visited.put(neighbor, new Node(neighbor.val, new ArrayList()));
                    // 将邻居节点加入队列中
                    queue.add(neighbor);
                }
                // 更新当前节点的邻居列表
                visited.get(n).neighbors.add(visited.get(neighbor));
            }
        }

        return visited.get(node);
    }




}

class Node {
    public int val;
    public List<Node> neighbors;
    public Node() {
        val = 0;
        neighbors = new ArrayList<Node>();
    }
    public Node(int _val) {
        val = _val;
        neighbors = new ArrayList<Node>();
    }
    public Node(int _val, ArrayList<Node> _neighbors) {
        val = _val;
        neighbors = _neighbors;
    }
}