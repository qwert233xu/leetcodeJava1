package com.xu;

import java.util.*;

// greed
public class App3 {
    public static void main(String[] args) {

    }

    //1、
    public String removeKdigits(String num, int k) {
        //贪心算法+栈
        if(k >= num.length()||num.length()==0)
            return "0";
        //栈顶始终是最大值
        Stack<Integer>stack=new Stack<>();
        stack.push(num.charAt(0)-'0');
        for(int i=1;i<num.length();i++)
        {
            int now=num.charAt(i)-'0';
            //可能好几个值都比当前值大，那么我们就在k允许的情况下，去去除它。
            while(!stack.isEmpty()&&k>0&&now<stack.peek()){
                stack.pop();
                k--;
            }
            //不等于0可以添加进去,
            //等于0，栈不为空可以填进去，
            if(now!=0||!stack.isEmpty())
            {
                stack.push(now);
            }
        }
        //56789这种情况，前面一直比后面小，那就去除栈顶，谁让栈顶最大
        while(k>0 && !stack.isEmpty())
        {
            k--;
            stack.pop();
        }
        //10，1(当now=0时，满足条件，去掉1，但now为0，且为空。)
        if(stack.isEmpty())
            return "0";
        StringBuilder sb=new StringBuilder();
        while(!stack.isEmpty())
            sb.append(stack.pop());
        //从后往前添加所以我们要逆序
        return sb.reverse().toString();
    }

    //2、
    public String removeDuplicateLetters(String s) {

        // 计数
        int[] counter = new int[256];
        for (char c: s.toCharArray()) {
            counter[c] ++;
        }

        Stack<Character> stack = new Stack<>();
        boolean[] used = new boolean[256];

        // 去重
        for (char c: s.toCharArray()) {
            counter[c]--;
            if (used[c]){  // 去重
                continue;
            }
            while (!stack.isEmpty() && c < stack.peek()){ // 保证字典序最小

                if (counter[stack.peek()] == 0){
                    break;
                }

                used[stack.pop()] = false;
            }
            stack.push(c);
            used[c] = true;
        }

        StringBuilder res = new StringBuilder();
        while (!stack.isEmpty()){
            res.append(stack.peek());
            stack.pop();
        }
        return res.reverse().toString();
    }


    // 3、
    public String smallestSubsequence(String s) {
        // 计数
        int[] counter = new int[256];
        for (char c: s.toCharArray()) {
            counter[c] ++;
        }

        Stack<Character> stack = new Stack<>();
        boolean[] used = new boolean[256];

        // 去重
        for (char c: s.toCharArray()) {
            counter[c]--;
            if (used[c]){  // 去重
                continue;
            }
            while (!stack.isEmpty() && c < stack.peek()){ // 保证字典序最小

                if (counter[stack.peek()] == 0){
                    break;
                }

                used[stack.pop()] = false;
            }
            stack.push(c);
            used[c] = true;
        }

        StringBuilder res = new StringBuilder();
        while (!stack.isEmpty()){
            res.append(stack.peek());
            stack.pop();
        }
        return res.reverse().toString();
    }

    // 4、分治思想  贪心局部最优
    public int[] maxNumber(int[] nums1, int[] nums2, int k) {

        int[] res = new int[k];
        Arrays.fill(res, -1);
        for (int i = 0; i < k + 1; i++) {
            if (i <= nums1.length && k - i <= nums2.length){
                int[] cur = merge(pick_max(nums1, i), pick_max(nums2, k - i));
                for (int j = 0; j < k; j++) {
                    if (res[j] > cur[j]){
                        break;
                    }else if (res[j] < cur[j]){
                        res = cur;
                        break;
                    }
                }
            }
        }
        return res;
    }

    public int[] pick_max(int[] nums, int k){
        int[] res = new int[k];
        Stack<Integer> stack = new Stack<>();

        int m = nums.length - k;
        for (int num : nums) {
            while (!stack.isEmpty() && m > 0 && stack.peek() < num) {
                stack.pop();
                m--;
            }
            stack.push(num);
        }

        while (m > 0){
            stack.pop();
            m --;
        }

        int i = k-1;
        while (i >= 0) {
            res[i--] = stack.pop();
        }

        System.out.println(Arrays.toString(res));
        System.out.println("========pick_max=========");
        return res;
    }

    public String str(int[] nums, int i){
        // return  ''.join(nums[i:])
        if(i>=nums.length) return "";
        StringBuilder sb = new StringBuilder();
        for(; i<nums.length; i++){
            sb.append((char)(nums[i]+'a'));
        }
        return sb.toString();
    }

    public int[] merge(int[] A, int[] B){ // 可以出一道题: 给定两个字符串，在不改变其相对位置的情况下，组合成最大的数
        int n=A.length, m=B.length, l=n+m;
        int[] res = new int[l];
        int i=0, j=0;
        for(int k=0; k<l; k++){
            int a = i>=n ? -1 : A[i];
            int b = j>=m ? -1 : B[j];
            if(a>b){
                res[k] = a;
                i++;
            }else if (b>a){
                res[k] = b;
                j++;
            }else{
                // 如果相等，则比较后序字符大小
                String s1 = str(A, i);
                String s2 = str(B, j);
                if((s1+s2).compareTo(s2+s1)>0){
                    res[k] = a;
                    i++;
                }else{
                    res[k] = b;
                    j++;
                }
            }
        }
        return res;
    }

    //5、
    public int[][] reconstructQueue(int[][] people) {
        // 原地该变
        Arrays.sort(people, new Comparator<int[]>() {
            @Override
            public int compare(int[] o1, int[] o2) {
                if (o1[0] != o2[0]){
                    return o2[0] - o1[0];
                }else {
                    return o1[1] - o2[1];
                }
            }
        });

        List<int[]> list = new LinkedList<>();

        for (int[] person : people) {

            list.add(Math.min(list.size(), person[1]), person);
        }

        return list.toArray(new int[list.size()][]);
    }

    // 6、
    public int longestPalindrome(String s) {
        char[] occurs = new char[128];

        int ans = 0;
        for (int i = 0; i < s.length(); ++i) {
            char c = s.charAt(i);
            occurs[c]++;
            if (occurs[c] == 2) {
                ans += 2;
                occurs[c] = 0;
            }
        }

        if (ans < s.length()) ans++;
        return ans;
    }

    // 7、
    public int eraseOverlapIntervals(int[][] intervals) {
        if (intervals.length < 2) return 0;

        Arrays.sort(intervals, (a, b) -> a[1] - b[1]);

        int res = 1;
        int right = intervals[0][1];
        for (int i = 1; i < intervals.length; i++) {
            if (intervals[i][0] >= right){
                res++;
                right = intervals[i][1];
            }

        }
        return intervals.length - res;
    }

    // 8、
    public int findContentChildren(int[] g, int[] s) {
        int i = 0;
        int j = 0;

        Arrays.sort(g);
        Arrays.sort(s);
        while (i < s.length && j < g.length){
            if (g[j] <= s[i++]){
                j++;
            }
        }

        return j;
    }

    // 9、
    public int arrayPairSum(int[] nums) {
        if (nums.length == 2){
            return Arrays.stream(nums).min().getAsInt();
        }

        Arrays.sort(nums);

        int i = 0;
        int j = 1;

        int res = 0;
        while (j < nums.length){
            res += Math.min(nums[i], nums[j]);
            i+=2;
            j+=2;
        }

        return res;
    }

    // 10、
    public boolean canPlaceFlowers(int[] flowerbed, int n) {

        for (int i = 0; i < flowerbed.length && n > 0;) {
            if (flowerbed[i] == 1){
                i+=2;
            }else if (i == flowerbed.length - 1 || flowerbed[i+1] == 0){
                n--;
                i+=2;
            }else {
                i+=3;
            }
        }

        return n == 0;
    }

    // 11、
    public boolean validPalindrome(String s) {

        int left = 0;
        int right = s.length()- 1;
        while (left < right){
            if (s.charAt(left) != s.charAt(right)){
                return judge(s, left+1, right) || judge(s, left, right-1);
            }else {
                left++;
                right--;
            }
        }

        return true;
    }

    public boolean judge(String s, int left, int right){
        while (left < right){
            if (s.charAt(left++) != s.charAt(right--)){
                return false;
            }
        }
        return true;
    }

    // 12、
    public boolean lemonadeChange(int[] bills) {
        int five = 0;
        int ten = 0;


        for (int bill : bills) {
            if (bill == 5) {
                five++;
            } else if (bill == 10) {
                if (five > 0) {
                    five--;
                    ten++;
                } else {
                    return false;
                }
            } else {
                if (five > 0 && ten > 0) { // 贪心  优先使用 10 和 5 留着 5 5
                    five--;
                    ten--;
                } else if (five >= 3) {
                    five -= 3;
                } else {
                    return false;
                }
            }
        }
        return true;
    }

    // 13、
    public int[] diStringMatch(String s) {
        if (s.length() == 1){
            if (s.charAt(0) == 'I'){
                return new int[]{0, 1};
            }
            return new int[]{1, 0};
        }

        int n = s.length() + 1;

        int[] res = new int[n];

        int min = 0;
        int max = n - 1;
        for (int i = 0; i < s.length(); i++) {  // 贪心  遇到 D 优先使用最大值， 遇到 I 优先使用最小值
            if (s.charAt(i) == 'I'){
                res[i] = min;
                min++;
            }else {
                res[i] = max;
                max--;
            }
        }
        System.out.println(max);
        res[n - 1] = min; // or  max
        return res;
    }

    // 14、
    public int largestPerimeter(int[] nums) {

        int[] ints = new int[nums.length];
        Arrays.sort(nums);
        int index = nums.length - 1;
        for (int v: nums) {
            ints[index--] = v;
        }

        int res = 0;
        for (int i = 0; i < ints.length - 2; i++) {
            if (judge(ints[i], ints[i+1], ints[i+2])){
                res = Math.max(res,ints[i] + ints[i+1] + ints[i+2]);
            }
        }

        return res;
    }

    public boolean judge(int a, int b, int c){
        return a + b > c && a + c > b && b + c > a;
    }

    // 15、
    public int largestSumAfterKNegations(int[] nums, int k) {
        
        int res = 0;
        Arrays.sort(nums);
        
        int fCount = 0; // 负数个数
        boolean zeroValue = false; // 是否有零

        for (int v: nums) {
            if (v < 0){
                fCount++;
            }
            if (v == 0){
                zeroValue = true;
            }
        }

        int index_absMin = 0;  // 绝对值最小的值 所在索引
        int min_absValue = Math.abs(nums[0]);
        for (int i = 1; i < nums.length; i++) {
            if (min_absValue > Math.abs(nums[i])){
                index_absMin = i;
                min_absValue = Math.abs(nums[i]);
            }
        }
        
        int k2 = k;
        if (k <= fCount){
            for (int v: nums) {
                if (v < 0 && k2 > 0){
                    res += (-v);
                    k2--;
                }else {
                    res += v;
                }
            }
            return res;
        }else {
            // 计算出剩余取反次数
            for (int i = 0; i < fCount; i++) {
                res += (-nums[i]);
            }
            if ((k - fCount) % 2 == 0 || zeroValue){
                // 偶数
                for (int i = fCount; i < nums.length; i++) {
                    res+=nums[i];
                }
                return res;
            }else {
                for (int i = fCount; i < nums.length; i++) {
                    res += nums[i];
                }
                System.out.println("=====");
                System.out.println(Arrays.toString(nums));
                System.out.println(index_absMin);

                return res - 2*Math.abs(nums[index_absMin]);
            }
        }
    }










}
