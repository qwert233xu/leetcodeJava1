package com.xu;

import org.testng.annotations.Test;

import java.util.*;

// dynamic process
public class App2 {
    public static void main(String[] args) {

    }

    // O(n)   1
    public int MaxSubArray(int[] nums) {
        if (nums.length == 1) return nums[0];

        int[] dp = new int[nums.length]; // 表示以 nums[i] 结尾 的 连续 子数组的最大和
        dp[0] = nums[0];
        int res = nums[0];
        for (int i = 1; i < nums.length; i++) {
           dp[i] = Math.max(dp[i - 1] + nums[i], nums[i]);
           res = Math.max(dp[i], res); // -3  8  -2  -3
        }
        return res;
    }

    //   2
    // [2,3,1,1,4] true   [3,2,1,0,4] false
    // [2,0]
    public boolean canJump(int[] nums) {

        int border = 0;
        int end = 0;

        for (int i = 0; i < nums.length-1; i++) {
            border = Math.max(border, nums[i] + i);
            if (i == end){
                end = border;
            }
        }
        if (end >= nums.length - 1) return true;
        return end + nums[end] >= nums.length - 1;
    }

    private int res_count = 0;

    // backTracking     over time!
    public int uniquePaths(int m, int n) {

        boolean[][] used = new boolean[m][n];
        backTracking_uniquePaths(used, 0, 0, m, n);
        return res_count;
    }

    public void backTracking_uniquePaths(boolean[][] used, int i, int j, int m, int n){
        used[i][j] = true;
        if (i == m - 1 && j == n - 1){
            res_count++;
            return;
        }
        int[][] choice = new int[][]{{0, 1}, {1, 0}};
        for (int[] ints : choice) {
            int newI = i + ints[0];
            int newJ = j + ints[1];
            if (newI < used.length && newJ < used[0].length && !used[newI][newJ]) {
                backTracking_uniquePaths(used, newI, newJ, m, n);
                used[newI][newJ] = false;
            }
        }
    }

    //  3
    // dynamic process    O(n2)
    public int uniquePaths2(int m, int n) {
        // i   j     dp[i][j] 表示从 0 0 到 i j 路径总数
        // 只有上部 和 左部 能到达  dp[i][j] = dp[i-1][j] + dp[i][j-1]
        int[][] dp = new int[m][n];
        // 处理边界  上边界 和 左边界  只有一条路径
        for (int i = 0; i < m; i++) {
            dp[i][0] = 1;
        }
        for (int i = 0; i < n; i++) {
            dp[0][i] = 1;
        }

        for (int i = 1; i < m; i++) {
            for (int j = 1; j < n; j++) {
                dp[i][j] = dp[i-1][j] + dp[i][j-1];
            }
        }

        return dp[m-1][n-1];
    }


    // 4  带障碍物    障碍物 1    无障碍物 0
    public int uniquePathsWithObstacles(int[][] obstacleGrid) {
        if (obstacleGrid == null || obstacleGrid.length == 0) return 0;


        int m = obstacleGrid.length;
        int n = obstacleGrid[0].length;



        int[][] dp = new int[m][n];
        // 处理边界  上边界 和 左边界  只有一条路径
        int border = 0;
        for (int i = 0; i < m && obstacleGrid[i][0] == 0; i++) {
                dp[i][0] = 1;
        }

        for (int i = 0; i < n && obstacleGrid[0][i] == 0; i++) {
            dp[0][i] = 1;
        }

        for (int i = 1; i < m; i++) {
            for (int j = 1; j < n; j++) {
                // 障碍物判断
                if (obstacleGrid[i][j] != 1) {
                    dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
                }
            }
        }
        return obstacleGrid[m-1][n-1] != 1?dp[m-1][n-1]:0;

    }

    // 5、
    public int minPathSum(int[][] grid) {

        if (grid == null || grid.length == 0) return 0;

        int m = grid.length;
        int n = grid[0].length;


        int[][] dp = new int[m][n];
        dp[0][0] = grid[0][0];
        // 处理边界  上边界 和 左边界  只有一条路径
        for (int i = 1; i < m; i++) {
            dp[i][0] = grid[i][0] + dp[i - 1][0];
        }
        for (int i = 1; i < n; i++) {
            dp[0][i] = grid[0][i] + dp[0][i - 1];
        }

        for (int i = 1; i < m; i++) {
            for (int j = 1; j < n; j++) {
                dp[i][j] = Math.min(dp[i-1][j], dp[i][j-1]) + grid[i][j];
            }
        }

        return dp[m-1][n-1];

    }

    // 6、
    public int climbStairs(int n) {

        if (n == 0) return 0;
        if (n == 1) return 1;

        int[] dp = new int[n+1];
        dp[0] = 1;
        dp[1] = 1;
        for (int i = 2; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }

        return dp[n];
    }

    // 7、
    public List<List<Integer>> generate(int numRows) {
        List<List<Integer>> dp = new ArrayList<>(numRows);
        ArrayList<Integer> initial = new ArrayList<>();
        initial.add(1);
        if (numRows >= 1) dp.add(0, initial);
        ArrayList<Integer> initial2 = new ArrayList<>();
        if (numRows >= 2) {
            initial2.add(1);
            initial2.add(1);
        }
        dp.add(1, initial2);

        for (int i = 2; i < numRows; ++i) {
            ArrayList<Integer> temp = new ArrayList<>();
            temp.add(0, 1);
            for (int j = 1; j <= i - 1; ++j) {
                temp.add(j, dp.get(i-1).get(j) + dp.get(i - 1).get(j - 1));
            }

            temp.add(1);
            dp.add(temp);
        }

        return dp;
    }

    // 8、
    public int maxProfit(int[] prices) {

        if (prices.length == 1) return 0;

        int[][] dp = new int[prices.length][2];  // 0 不持有  1  持有
        dp[0][0] = 0;
        dp[0][1] = -prices[0];

        for (int i = 1; i < prices.length; i++) {
            dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] + prices[i]);
            dp[i][1] = Math.max(dp[i - 1][1], -prices[i]);
        }

        return Math.max(dp[prices.length - 1][0], 0);
    }

    // 9、
    public List<List<String>> partition(String s) {
        int len = s.length();
        List<List<String>> res = new ArrayList<>();
        if (len == 0) {
            return res;
        }

        char[] charArray = s.toCharArray();
        // 预处理
        // 状态：dp[i][j] 表示 s[i][j] 是否是回文
        boolean[][] dp = new boolean[len][len];
        // 状态转移方程：在 s[i] == s[j] 的时候，dp[i][j] 参考 dp[i + 1][j - 1]
        for (int right = 0; right < len; right++) {
            // 注意：left <= right 取等号表示 1 个字符的时候也需要判断
            for (int left = 0; left <= right; left++) {
                if (charArray[left] == charArray[right] && (right - left <= 2 || dp[left + 1][right - 1])) {
                    dp[left][right] = true;
                }
            }
        }

        Deque<String> stack = new ArrayDeque<>();
        dfs(s, 0, len, dp, stack, res);
        return res;
    }

    private void dfs(String s, int index, int len, boolean[][] dp, Deque<String> path, List<List<String>> res) {
        if (index == len) {
            res.add(new ArrayList<>(path));
            return;
        }

        for (int i = index; i < len; i++) {
            if (dp[index][i]) {  // index =》 left   i =》 right
                path.addLast(s.substring(index, i + 1)); // 截取字符串  （回文子串）
                System.out.println(i+1);
                dfs(s, i + 1, len, dp, path, res);  // i + 1  i 为 right （索引）  当回溯到该子串右边界时，保存满足的组合
                path.removeLast();
            }
        }
    }


    public List<List<String>> partition_test(String s) {

        List<List<String>> res = new ArrayList<>();
        ArrayList<String> temp = new ArrayList<>();

        int index = 0;
        dfs_test(s, res, temp, index);
        return res;
    }

    private void dfs_test(String s, List<List<String>> res, ArrayList<String> temp, int index) {
        if (index == s.length()) {
//        if (temp.size() == s.length()) { // 和 i = 0 搭配着使用 排列问题
            res.add(new ArrayList<>(temp));
            return;
        }

        for (int i = index; i < s.length(); i++) {   // 当 i = 0 时表示可以重复选（排列）   index 的情况表示不可重复选（组合）
            temp.add(s.substring(index, i+1));  // 分割问题
//            temp.add(String.valueOf(s.charAt(i)));
            dfs_test(s, res, temp, i+1);
            temp.remove(temp.size() - 1);
        }
    }

    // 10、
    public int maxProduct(int[] nums) {
        int n = nums.length;

        int[] maxNums = new int[n]; // 以j结尾的最大乘积子数组  正数情况
        int[] minNums = new int[n]; // 以j结尾的最小乘积子数组  负数情况

        System.arraycopy(nums, 0, maxNums, 0, n);
        System.arraycopy(nums, 0, minNums, 0, n);


        for (int i = 1; i < n; i++) {
                maxNums[i] = Math.max(maxNums[i - 1]*nums[i], Math.max(minNums[i - 1]*nums[i], nums[i]));
                minNums[i] = Math.min(minNums[i - 1]*nums[i], Math.min(maxNums[i - 1]*nums[i], nums[i]));
        }

        int max = maxNums[0];
        for (int i = 1; i < n; i++) {
            max = Math.max(max, maxNums[i]);
        }

        return max;
    }
    // 11、
    public int rob(int[] nums) {
        if(nums.length == 1) return nums[0];
        int[][] dp = new int[nums.length][2]; // 0 tou  1 butou
        dp[0][0] = nums[0];
        dp[0][1] = 0;

        for (int i = 1; i < nums.length; i++) {
            dp[i][0] = dp[i - 1][1] + nums[i];
            dp[i][1] = Math.max(dp[i - 1][0], dp[i - 1][1]); // 但是可以隔多家butou
        }

        return Math.max(dp[nums.length - 1][0], dp[nums.length - 1][1]);
    }

    // 12、 环形
    public int rob2(int[] nums) {

        if (nums.length == 1){
            return nums[0];
        }else if (nums.length == 2){
            return Math.max(nums[0], nums[1]);
        }

        return Math.max(MaxDiff(Arrays.copyOfRange(nums, 1, nums.length)), MaxDiff(Arrays.copyOfRange(nums, 0, nums.length-1)));

    }

    public int MaxDiff(int[] nums){
        if(nums.length == 1) return nums[0];
        int[][] dp = new int[nums.length][2];
        dp[0][0] = nums[0];
        dp[0][1] = 0;

        for (int i = 1; i < nums.length; i++) {
            dp[i][0] = dp[i - 1][1] + nums[i];
            dp[i][1] = Math.max(dp[i - 1][0], dp[i - 1][1]);
        }

        return Math.max(dp[nums.length - 1][0], dp[nums.length - 1][1]);
    }

    // 13、
    public int maximalSquare(char[][] matrix) {
        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) return 0;

        int[][] dp = new int[matrix.length][matrix[0].length];
        int res = 0;
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                if (matrix[i][j] == '1'){
                    if (i == 0 || j == 0){
                        dp[i][j] = 1;
                        res = Math.max(res, dp[i][j]);
                    }else {
                        dp[i][j] =Math.min(Math.min(dp[i][j-1], dp[i-1][j]), dp[i-1][j-1]) + 1;
                        res = Math.max(res, dp[i][j]);
                    }
                }
            }
        }
        return res * res;
    }

    // 14、
    public List<Integer> diffWaysToCompute(String expression) {
        return diffWaysToCompute_Partition(expression);
    }


    public List<Integer> diffWaysToCompute_Partition(String s){

        ArrayList<Integer> res = new ArrayList<>();
        if (s.length() < 3){
            res.add(Integer.parseInt(s));
            return res;
        }


        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '+' || s.charAt(i) == '-' || s.charAt(i) == '*'){
                // 分治
                List<Integer> left = diffWaysToCompute_Partition(s.substring(0, i));
                List<Integer> right = diffWaysToCompute_Partition(s.substring(i+1, s.length()));

                for (Integer value : left) {
                    for (Integer integer : right) {
                        if (s.charAt(i) == '+') {
                            res.add(value + integer);
                        } else if (s.charAt(i) == '-') {
                            res.add(value - integer);
                        } else if (s.charAt(i) == '*') {
                            res.add(value * integer);
                        }
                    }
                }
            }
        }
        return res;
    }

    // 15、
    public int nthUglyNumber(int n) {
        if (n == 1) return 1;

        int[] dp = new int[n + 1];  // dp[i]  存放第几个丑数
        dp[1] = 1;

        int a2 = 1, a3 = 1, a5 = 1;
        for (int i = 2; i <= n; i++) {
            int a = dp[a2] * 2;
            int b = dp[a3] * 3;
            int c = dp[a5] * 5;

            int minValue = Math.min(Math.min(a, b), c);
            dp[i] = minValue;  // 可能有  2  和  3  共同组成的情况，所以为 if  而非 else if
            if (dp[i] == a){
                a2++;
            }
            if (dp[i] == b){
                a3++;
            }
            if (dp[i] == c){
                a5++;
            }
        }

        return dp[n];
    }

    // 16、
    public int numSquares(int n) {
        int[] dp = new int[n + 1]; // 默认初始化值都为0     索引是数，值是个数

        for (int i = 1; i <= n; i++) { // dp[1] = 1(1)   dp[2] = 2 (1 1)    dp[3] = 3 (1 1 1)  dp[8] = 2 (4 4)
            dp[i] = i; // 最坏的情况就是每次+1

            for (int j = 1; j * j <= i; j++) {
                dp[i] = Math.min(dp[i], dp[i - j * j] + 1); // 动态转移方程
            }

        }
        System.out.println(Arrays.toString(dp));
        return dp[n];
    }


    // 17、 树形动态规划  记录两个状态   递归太耗时
    public int rob(TreeNode root) {
        int[] max = rob_dfs(root);
        return Math.max(max[0], max[1]);
    }

    public int[] rob_dfs(TreeNode root){
        if (root == null){
            return new int[2];
        }

        int[] res = new int[2];

        int[] left =  rob_dfs(root.left);
        int[] right =  rob_dfs(root.right);

        res[0] = Math.max(left[0], left[1]) + Math.max(right[0], right[1]);
        res[1] = left[0] + right[0] + root.val;

        return res;
    }


    // 18、
    public int integerBreak(int n) {

        int[] dp = new int[n + 1];

        for (int i = 2; i <= n; i++) {
            int ans = 0;
            for (int j = 1; j < i; j++) {
                ans = Math.max(ans, Math.max(j * (i - j), j * dp[i - j]));
            }
            dp[i] = ans;
        }
        return dp[n];
    }

    // 19、
    public int countNumbersWithUniqueDigits(int n) {
        if (n == 0) return 1;

        int res = 10;
        for (int i = 2, last = 9; i <= n; i++) {
            int ans = last * (10 - i + 1); //   last   9   8    7
            res += ans;
            last = ans;
        }

        return res;
    }

    // 20、
    public int combinationSum4(int[] nums, int target) {

        int[] dp = new int[target + 1];
        dp[0] = 1;
        for (int i = 1; i <= target; i++) {
            for (int v: nums) {
                if (i >= v){
                    dp[i] += dp[i - v];
                }
            }
        }

        return dp[target];
    }

    // 21、最长回文子串   回文子串个数 就是dp数组里 true 个数
    public int longestPalindromeSubseq1(String s) {
        if (s.length() == 1) return 1;

        int n = s.length();
        boolean[][] dp = new boolean[n][n];
        for (int i = 0; i < n; i++) {
            dp[i][i] = true;
        }

        int res = 1;
        for (int i = n - 1; i >= 0; i--) {  // 开始索引   从小到上
            int ans = 1;
            for (int j = i; j < n; j++) {  // 结束索引   从左到右
                if (s.charAt(i) == s.charAt(j)){
                    if (j - i < 3){
                        dp[i][j] = true;
                    }else if (dp[i+1][j-1]){
                        dp[i][j] = true;
                    }
                }
                if (dp[i][j]){
                    ans = Math.max(ans, j - i + 1);
                }
            }
            res = Math.max(res, ans);
        }
        return res;
    }

    // 22、最长回文子序列
    public int longestPalindromeSubseq(String s) {
        if (s.length() == 1) return 1;

        int n = s.length();
        int[][] dp = new int[n][n]; // 表示第 i 个 索引到 第 j 个索引的最长回文子序列的长度
        for (int i = 0; i < n; i++) {
            dp[i][i] = 1;
        }

        for (int i = n - 1; i >= 0; i--) {  //
            for (int j = i + 1; j < n; j++) {
                if (s.charAt(i) == s.charAt(j)){
                    dp[i][j] = dp[i + 1][j - 1] + 2;  // 体现非连续性
                    // 可以计数统计回文子序列 个数
                }else {
                    dp[i][j] = Math.max(dp[i+1][j], dp[i][j-1]);
                }
            }
        }

        return dp[0][n-1];
    }


    // 23、
    public boolean isSubsequence(String s, String t) {
        if (s.length() == 0) return true;

        if (s.length() > t.length()) return false;

        int n = t.length();

        int i_s = 0;
        int j_t = 0;

        while (j_t < n){
            if (s.charAt(i_s) == t.charAt(j_t)){
                i_s++;
            }
            j_t++;
        }
        return i_s == s.length();
    }

    // 24、分割等和子集
    public boolean canPartition(int[] nums) {
        if (nums.length < 2) return false;

        int target = 0;
        for (int v: nums) {
            target += v;
        }

        if (target % 2 != 0) return false;
        target /= 2;  // 背包
        int n = nums.length;
        boolean[][] dp = new boolean[n][target + 1]; // dp[i][j]表示判断从数组的 [0, i] 这个子区间内挑选一些正整数，每个数只能用一次，使得这些数的和恰好等于 j。
        if (nums[0] <= target){
            dp[0][nums[0]] = true;
        }
        for (int i = 1; i < n; i++) {  // 物品 索引
            for (int j = 0; j <= target; j++) { // 背包容量
                dp[i][j] = dp[i - 1][j];
                if (nums[i] == j){
                    dp[i][j] = true;
                    continue;
                }
                if (nums[i] < j){
                    dp[i][j] = dp[i - 1][j] || dp[i - 1][j - nums[i]]; // 不选  与  选
                }
            }
        }

        return dp[n-1][target];
    }



    // 25、目标和
    public int findTargetSumWays(int[] nums, int target) {
        int sum = 0;
        for (int num : nums) {
            sum += num;
        }
        // 绝对值范围超过了sum的绝对值范围则无法得到
        if (Math.abs(target) > Math.abs(sum)) return 0;

        int len = nums.length;
        // - 0 +
        int t = sum * 2 + 1;
        int[][] dp = new int[len][t];

        // 初始化
        if (nums[0] == 0) {
            dp[0][sum] = 2;
        } else {
            dp[0][sum + nums[0]] = 1;
            dp[0][sum - nums[0]] = 1;
        }

        for (int i = 1; i < len; i++) {
            for (int j = 0; j < t; j++) {
                // 边界
                int l = Math.max((j - nums[i]), 0);
                int r = (j + nums[i]) < t ? j + nums[i] : 0;
                dp[i][j] = dp[i - 1][l] + dp[i - 1][r];
            }
        }
        return dp[len - 1][sum + target];
    }

    // 26、回文子串个数
    public int countSubstrings(String s) {

        if (s.length() == 1) return 1;

        int n = s.length();
        boolean[][] dp = new boolean[n][n];
        for (int i = 0; i < n; i++) {
            dp[i][i] = true;
        }

        int res = 0;
        for (int i = n - 1; i >= 0; i--) {  // 开始索引   从小到上
            int ans = 1;
            for (int j = i; j < n; j++) {  // 结束索引   从左到右
                if (s.charAt(i) == s.charAt(j)){
                    if (j - i < 3){
                        dp[i][j] = true;
                    }else if (dp[i+1][j-1]){
                        dp[i][j] = true;
                    }
                }
                if (dp[i][j]){
                    ans = Math.max(ans, j - i + 1);
                    res ++;
                }
            }
        }

        return res;
    }



}
